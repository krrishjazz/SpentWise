class ApplicationMailer < ActionMailer::Base
  default from: "krishna.jaiswal2019@vitstudent.ac.in"
  layout "mailer"
end
