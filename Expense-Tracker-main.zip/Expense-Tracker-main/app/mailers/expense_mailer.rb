class ExpenseMailer < ApplicationMailer
end
