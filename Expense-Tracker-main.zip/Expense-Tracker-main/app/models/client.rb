class Client < ApplicationRecord
    has_secure_password
end
