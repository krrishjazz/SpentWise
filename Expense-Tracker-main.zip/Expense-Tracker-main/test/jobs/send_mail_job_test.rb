require "test_helper"

class SendMailJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
